PDF Form Filling and Flattening Tool for Windows
================================================

Version 3.0  November 21, 2005

Copyright (C) 1995-2005 PDF Tools AG

http://www.pdf-tools.com
pdfsupport@pdf-tools.com

File list
=========

readme.txt                  This file
bin/pdformp.exe             Executable programs
bin/pdform.pdf              Documentation
bin/pdf-license-v1.4.pdf    License terms for binary pdf tools

Installation
============

1. Unpack the archive in an installation directory, i.e. C:/Program Files/pdf-tools/
2. Include the bin directory in the PATH variable.

